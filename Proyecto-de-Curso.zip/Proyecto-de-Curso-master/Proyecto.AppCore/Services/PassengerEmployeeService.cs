﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Services
{
    public class PassengerEmployeeService : Base<PassengerEmployee>, IPassengerEmployeeServices
    {
        IPassengerEmployeeModel model;

        public PassengerEmployeeService(IPassengerEmployeeModel model): base(model)
        {
            this.model = model;
        }
        public List<PassengerEmployee> FindByEmployeeId(int EmployeeId)
        {
            return model.FindByEmployeeId(EmployeeId);
        }

        public PassengerEmployee FindByPassengerEmployeeId(int EmployeeId, int PassengerId)
        {
            return model.FindByPassengerEmployeeId(EmployeeId, PassengerId);
        }

        public List<PassengerEmployee> FindByPassengerId(int PassengerId)
        {
            return model.FindByPassengerId(PassengerId);
        }
    }
}
