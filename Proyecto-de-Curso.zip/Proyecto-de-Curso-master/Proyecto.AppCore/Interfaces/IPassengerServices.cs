﻿using Proyecto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Interfaces
{
    public interface IPassengerServices : IServices<Passenger>
    {
        List<Passenger> FindByName(String name);
        Passenger FindById(int id);
        float AmountToPayBySuitcases(Passenger passenger);
        float PriceOfFligth(Fligth fligth);
    }
}
