﻿using Proyecto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Interfaces
{
    public interface IEmployeeServices : IServices<Employee>
    {
        List<Employee> FindByName(String name);
        Employee FindById(int id);
    }
}
