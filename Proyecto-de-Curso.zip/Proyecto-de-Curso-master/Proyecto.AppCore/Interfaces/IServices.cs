﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.AppCore.Interfaces
{
    public interface IServices<T>
    {
        void Create(T t);
        bool Delete(T t);
        bool Update(T t);
        List<T> Read();
    }
}
