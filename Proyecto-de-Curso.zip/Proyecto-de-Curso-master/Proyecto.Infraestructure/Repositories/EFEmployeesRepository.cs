﻿using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Infraestructure.Repositories
{
    public class EFEmployeeRepository : IEmployeeModel
    {
        public IAerolineDBContext aerolineDBContext;
        public EFEmployeeRepository(IAerolineDBContext aerolineDBContext)
        {
            this.aerolineDBContext = aerolineDBContext;
        }
        public int Create(Employee t)
        {
            try
            {
                aerolineDBContext.Employees.Add(t);
                return aerolineDBContext.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(Employee t)
        {
            int result = 0;
            try
            {
                if (t == null)
                {
                    throw new ArgumentNullException("El objeto empleado no puede ser null");
                }

                Employee empleado = FindById(t.Id);

                if (empleado == null)
                {
                    throw new ArgumentNullException("Empleado no puede ser null");
                }

                aerolineDBContext.Employees.Remove(empleado);
                result = aerolineDBContext.SaveChanges();

                return result > 0;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Employee FindById(int id)
        {
            try
            {
                if (id <= 0)
                {
                    throw new ArgumentException("El id no puede ser 0 o menor");
                }

                return aerolineDBContext.Employees.FirstOrDefault(x => x.Id == id);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<Employee> FindByName(string name)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(name))
                {
                    throw new Exception($"El parametro {name} no tiene el formato correcto");
                }

                return aerolineDBContext.Employees
                                        .Where(x => x.IdPersonNavigation.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase))
                                        .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<Employee> Read()
        {
            return aerolineDBContext.Employees.ToList();
        }
        public bool Update(Employee t)
        {
            bool result;

            try
            {
                if (t == null)
                {
                    throw new ArgumentException($"El parametro {t} no puede ser null");
                    result = false;
                }

                Employee employee = FindById(t.Id);

                if (employee == null)
                {
                    throw new Exception("El objeto no puede ser null");
                    result = false;
                }

                employee.IdPersonNavigation.Name = t.IdPersonNavigation.Name;
                employee.IdPersonNavigation.Lastname = t.IdPersonNavigation.Lastname;
                employee.IdPersonNavigation.Age = t.IdPersonNavigation.Age;
                employee.IdPersonNavigation.Gener = t.IdPersonNavigation.Gener;
                employee.IdPersonNavigation.Telephone = t.IdPersonNavigation.Telephone;
                employee.IdPersonNavigation.Email = t.IdPersonNavigation.Email;
                employee.IdPersonNavigation.CardId = t.IdPersonNavigation.CardId;
                employee.IdPersonNavigation.Datetime = t.IdPersonNavigation.Datetime;
                employee.WorkedCard = t.WorkedCard;

                aerolineDBContext.Employees.Update(employee);
                aerolineDBContext.SaveChanges();
                result = true;
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
    }
}
