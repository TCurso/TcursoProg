﻿using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Infraestructure.Repositories
{
    public class EFPassengerEmployeeRepository : IPassengerEmployeeModel
    {
        public IAerolineDBContext context;

        public EFPassengerEmployeeRepository(IAerolineDBContext context)
        {
            this.context = context;
        }
        public int Create(PassengerEmployee t)
        {
            try
            {
                if (t == null)
                {
                    throw new ArgumentNullException($"El paramtro {t} no puede ser null");
                }

                context.PassengersEmployees.Add(t);
                return context.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(PassengerEmployee t)
        {
            try
            {
                if (t == null)
                {
                    throw new ArgumentNullException($"El paramtro {t} no puede ser null");
                }

                context.PassengersEmployees.Remove(t);
                int result = context.SaveChanges();

                return result > 0;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<PassengerEmployee> FindByEmployeeId(int EmployeeId)
        {
            try
            {
                if (EmployeeId <= 0)
                {
                    throw new ArgumentNullException($"El paramtro {EmployeeId} no puede ser null");
                }

                return context.PassengersEmployees.Where(x => x.IdEmployee == EmployeeId).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public PassengerEmployee FindByPassengerEmployeeId(int EmployeeId, int PassengerId)
        {
            try
            {
                if (EmployeeId <= 0)
                {
                    throw new ArgumentNullException($"El paramtro {EmployeeId} no puede ser null");
                }

                if (PassengerId <= 0)
                {
                    throw new ArgumentNullException($"El paramtro {PassengerId} no puede ser null");
                }

                return context.PassengersEmployees.FirstOrDefault(x => x.IdEmployee == EmployeeId && x.IdPassenger == PassengerId);

            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<PassengerEmployee> FindByPassengerId(int PassengerId)
        {
            try
            {
                if (PassengerId <= 0)
                {
                    throw new ArgumentNullException($"El paramtro {PassengerId} no puede ser null");
                }

                return context.PassengersEmployees.Where(x => x.IdPassenger == PassengerId).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<PassengerEmployee> Read()
        {
            return context.PassengersEmployees.ToList();
        }
        public bool Update(PassengerEmployee t)
        {
            if (t == null)
            {
                throw new ArgumentNullException($"El parametro {t} no puede ser null");
            }

            PassengerEmployee passengerEmployee = FindByPassengerEmployeeId(t.IdEmployee, t.IdPassenger);

            if (passengerEmployee == null)
            {
                throw new Exception("El objeto no puede ser null");
            }

            passengerEmployee.IdEmployee = t.IdEmployee;
            passengerEmployee.IdPassenger = t.IdPassenger;

            context.PassengersEmployees.Update(passengerEmployee);
            int result = context.SaveChanges();
            return result > 0;
        }
    }
}
