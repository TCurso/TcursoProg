﻿using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Infraestructure.Repositories
{
    public class EFTicketRepository : ITicketModel
    {
        public IAerolineDBContext context;

        public EFTicketRepository(IAerolineDBContext context)
        {
            this.context = context;
        }
        public int Create(Ticket t)
        {
            try
            {
                if (t == null)
                {
                    throw new ArgumentNullException($"El paramtro {t} no puede ser null");
                }

                context.tickets.Add(t);
                return context.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(Ticket t)
        {
            int result;
            try
            {
                if (t == null)
                {
                    throw new ArgumentNullException($"El paramtro {t} no puede ser null");
                }

                context.tickets.Remove(t);
                result = context.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
            return result > 0;
        }
        public Ticket FindByCode(string code)
        {
            Ticket ticket = new Ticket();
            if (String.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException($"El parametro {code} no puede ser null");
            }

            return context.tickets.FirstOrDefault(x => x.TicketCode.Equals(code, StringComparison.CurrentCultureIgnoreCase));

        }
        public List<Ticket> FindByDate(DateTime date)
        {
            if (string.IsNullOrEmpty(date.ToShortDateString()))
            {
                throw new ArgumentNullException($"El paramtro {date} no puede ser null");
            }

            return context.tickets.Where(x => x.Date.Equals(date)).ToList();
        }
        public List<Ticket> Read()
        {
            try
            {
                return context.tickets.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Update(Ticket t)
        {

            if (t == null)
            {
                throw new ArgumentNullException($"El paramtro {t} no puede ser null");
            }

            Ticket ticket = (Ticket)context.tickets.Where(x => x.Id == t.Id);

            if (ticket == null)
            {
                throw new Exception($"El objeto {ticket} no puede ser null");
            }

            ticket.Date = t.Date;
            ticket.ExtraExpenses = t.ExtraExpenses;
            ticket.IdEmployee = t.IdEmployee;
            ticket.IdPassenger = t.IdPassenger;
            ticket.IdFligth = t.IdFligth;
            ticket.NetPrice = t.NetPrice;
            ticket.TicketCode = t.TicketCode;

            context.tickets.Update(ticket);
            int result = context.SaveChanges();
            return result > 0;
        }
    }
}
