﻿using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Infraestructure.Repositories
{
    public class EFPassengerRepository : IPassengersModel
    {
        public double[] priceOfSuitCase = new double[3];
        public double[] WeigthOfSuitcaseT = new double[3];


        public IAerolineDBContext aerolineDBContext;
        public float AmountToPayBySuitcases(Passenger passenger)
        {
            float Amount = 0;

            for (int i = 0; i < WeigthOfSuitcaseT.Length; i++)
            {
                WeigthOfSuitcaseT[i] = 20 * (i + 1);
            }

            for (int i = 0; i < priceOfSuitCase.Length; i++)
            {
                for (int j = 0; j < WeigthOfSuitcaseT.Length; j++)
                {
                    if (i == j)
                    {
                        priceOfSuitCase[i] = (WeigthOfSuitcaseT[i] / 0.625);
                    }
                }
            }

            try
            {
                for (int i = 0; i < WeigthOfSuitcaseT.Length; i++)
                {
                    if (passenger.WeigthOfSuitcase == WeigthOfSuitcaseT[i])
                    {
                        Amount = (float)priceOfSuitCase[i];
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Amount;
        }
        public int Create(Passenger t)
        {
            try
            {
                aerolineDBContext.Passengers.Add(t);
                return aerolineDBContext.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(Passenger t)
        {
            bool result = false;

            try
            {
                if (t == null)
                {
                    throw new ArgumentException($"El Parametro {t} no puede ser null");
                    result = false;
                }

                Passenger passenger = FindById(t.Id);

                if (passenger == null)
                {
                    throw new ArgumentException("El objeto no puede ser null");
                    result = false;
                }

                aerolineDBContext.Passengers.Remove(passenger);
                aerolineDBContext.SaveChanges();
                result = true;
            }
            catch (Exception)
            {
                throw;
            }

            return result;
        }
        public Passenger FindById(int id)
        {
            try
            {
                if (id <= 0)
                {
                    throw new Exception("El id no puede ser menor a 0");
                }

                return aerolineDBContext.Passengers.FirstOrDefault(x => x.Id == id);

            }
            catch (Exception)
            {
                throw;
            }

            return null;
        }
        public List<Passenger> FindByName(string name)
        {
            if (String.IsNullOrWhiteSpace(name))
            {
                throw new Exception($"El parametro {name} no puede ser vacio o null");
            }

            return aerolineDBContext.Passengers.Where(x => x.IdPersonNavigation.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase)).ToList();
        }

        public float PriceOfFligth(Fligth fligth)
        {
            throw new NotImplementedException();
        }

        public List<Passenger> Read()
        {
            return aerolineDBContext.Passengers.ToList();
        }
        public bool Update(Passenger t)
        {
            bool result = false;

            try
            {
                if (t == null)
                {
                    throw new Exception($"El parametro {t} no puede ser null");
                }

                Passenger passenger = FindById(t.Id);

                if (passenger == null)
                {
                    throw new Exception($"El objeto no puede ser null");
                }

                passenger.IdPersonNavigation.Name = t.IdPersonNavigation.Name;
                passenger.IdPersonNavigation.Lastname = t.IdPersonNavigation.Lastname;
                passenger.IdPersonNavigation.Age = t.IdPersonNavigation.Age;
                passenger.IdPersonNavigation.Gener = t.IdPersonNavigation.Gener;
                passenger.IdPersonNavigation.Telephone = t.IdPersonNavigation.Telephone;
                passenger.IdPersonNavigation.Email = t.IdPersonNavigation.Email;
                passenger.IdPersonNavigation.CardId = t.IdPersonNavigation.CardId;
                passenger.IdPersonNavigation.Datetime = t.IdPersonNavigation.Datetime;
                passenger.WeigthOfSuitcase = t.WeigthOfSuitcase;

                aerolineDBContext.Passengers.Update(passenger);
                aerolineDBContext.SaveChanges();

                return true;
            }
            catch (Exception)
            {
                throw;
            }
            return result;
        }
    }
}
