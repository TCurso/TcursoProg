﻿using Proyecto.AppCore.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto.Main
{
    public partial class FrmRegistros : Form
    {
        public ITicketServices ticketServices;
        public FrmRegistros()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvRegistros_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FrmRegistros_Load(object sender, EventArgs e)
        {
            dgvRegistros.DataSource = ticketServices.Read();
        }
    }
}
