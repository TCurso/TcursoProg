﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto.Main
{
    public partial class FrmBoleto : Form
    {
        public IPassengerServices passengerService;
        public IEmployeeServices employeeServices;
        public ITicketServices ticketServices;

        public FrmBoleto(IPassengerServices passengerService,
            IEmployeeServices employeeServices, ITicketServices ticketServices)
        {
            this.passengerService = passengerService;
            this.employeeServices = employeeServices;
            this.ticketServices = ticketServices;
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmBoleto_Load(object sender, EventArgs e)
        {
            cmbClase.DataSource = Enum.GetValues(typeof(FligthClass));
            cmbDestino.DataSource = listCountries();
        }

        public List<String> listCountries()
        {
            List<String> lista = new List<string>();

            lista.Add("United State");
            lista.Add("Canada");
            lista.Add("Mexico");
            lista.Add("Panama");
            lista.Add("Costa Rica");
            lista.Add("Brasil");
            lista.Add("Argentina");
            lista.Add("Ecuador");
            lista.Add("España");
            lista.Add("Colombia");

            return lista;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            Person person = new Person()
            {
                Name = txtNombre.Text,
                Lastname = txtApellido.Text
            };

            Passenger passenger = new Passenger()
            {
                IdPerson = person.Id 
            };

            passengerService.Create(passenger);

            Fligth fligth = new Fligth()
            {
                Destination = cmbDestino.SelectedItem.ToString(),
                FligthClass = cmbClase.SelectedItem.ToString()
            };

            Ticket ticket = new Ticket()
            {
                Date = dtFecha.Value,
                IdFligth = fligth.Id,
                IdPassenger = passenger.Id
            };

            ticketServices.Create(ticket);

            MessageBox.Show("El ticket fue agregado correctamente");
        }

        private void btnEnviar_Click_1(object sender, EventArgs e)
        {
            Person person = new Person()
            {
                Name = txtNombre.Text,
                Lastname = txtApellido.Text
            };

            Passenger passenger = new Passenger()
            {
                IdPerson = person.Id
            };

            //passengerService.Create(passenger);

            Fligth fligth = new Fligth()
            {
                Destination = cmbDestino.SelectedItem.ToString(),
                FligthClass = cmbClase.SelectedItem.ToString()
            };

            Ticket ticket = new Ticket()
            {
                Date = dtFecha.Value,
                IdFligth = fligth.Id,
                IdPassenger = passenger.Id
            };

            //ticketServices.Create(ticket);

            lblNombre.Text = txtNombre.Text;
            lblApellido.Text = txtApellido.Text;
            lblClase.Text = cmbClase.SelectedItem.ToString();
            lblDestino.Text = cmbDestino.SelectedItem.ToString();
            lblAsiento.Text = 40.ToString();
            lblFecha.Text = dtFecha.Value.ToString();

            Limpiar();

            MessageBox.Show("El ticket fue agregado correctamente");

        }

        private void Limpiar()
        {
            txtNombre.Text = String.Empty;
            txtApellido.Text = String.Empty;
            cmbDestino.Text = String.Empty;
            cmbClase.Text = String.Empty;
        }
    }
}
