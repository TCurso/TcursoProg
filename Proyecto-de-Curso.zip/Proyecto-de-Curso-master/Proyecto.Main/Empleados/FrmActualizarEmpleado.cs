﻿using Proyecto.AppCore.Interfaces;
using Proyecto.AppCore.Services;
using Proyecto.Domain.Entities;
using Proyecto.Infraestructure.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto.Main
{
    public partial class FrmActualizarEmpleado : Form
    {
        public IEmployeeServices employeeServices;
        public EFEmployeeRepository context;
        public FrmActualizarEmpleado(IEmployeeServices employeeServices)
        {
            this.employeeServices = employeeServices;
            InitializeComponent();
        }

        public FrmActualizarEmpleado()
        {
        }

        private void FrmActualizarEmpleado_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = employeeServices.Read();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Person persona = new Person()
            {
                Name = txtName.Text,
                Lastname = txtLastName.Text,
                Age = int.Parse(txtAge.Text),
                CivilState = txtCivilState.Text,
                CardId = txtCardId.Text,
                Gener = cmbGenero.SelectedItem.ToString(),
                Telephone = txtTelephone.Text,
                Email = txtEmail.Text,
                Datetime = dtFecha.Value
            };

            Employee employee = new Employee()
            {
                WorkedCard = txtCardId.Text,
                IdPerson = persona.Id
            };

            employeeServices.Delete(employee);
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            Person persona = new Person()
            {
                Name = txtName.Text,
                Lastname = txtLastName.Text,
                Age = int.Parse(txtAge.Text),
                CivilState = txtCivilState.Text,
                CardId = txtCardId.Text,
                Gener = cmbGenero.SelectedItem.ToString(),
                Telephone = txtTelephone.Text,
                Email = txtEmail.Text,
                Datetime = dtFecha.Value
            };

            Employee employee = new Employee()
            {
                WorkedCard = txtCardId.Text,
                IdPerson = persona.Id
            };

            employeeServices.Update(employee);
        }
    }
}
