﻿using Proyecto.AppCore.Interfaces;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto.Main
{
    public partial class FrmEmpleado : Form
    {
        public IEmployeeServices employeeServices;
        public FrmEmpleado(IEmployeeServices employeeService)
        {
            this.employeeServices = employeeServices;
            InitializeComponent();
        }

        public FrmEmpleado()
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ClearForms()
        {
            txtLastName.Clear();
            txtName.Clear();
            txtCardId.Clear();
            txtEmail.Clear();
            txtId.Clear();
            txtTelephone.Clear();
            cmbGenero.SelectedIndex = -1;
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            Person person = new Person()
            {
                Name = txtName.Text,
                Lastname = txtLastName.Text,
                Age = int.Parse(txtAge.Text),
                CivilState = txtCivilState.Text,
                CardId = txtCardId.Text,
                Gener = cmbGenero.SelectedItem.ToString(),
                Telephone = txtTelephone.Text,
                Email = txtEmail.Text,
                Datetime = dtFecha.Value
            };

            Employee employee = new Employee()
            {
                WorkedCard = txtCardId.Text,
                IdPerson = person.Id
            };

            employeeServices.Create(employee);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmEmpleado_Load(object sender, EventArgs e)
        {
            cmbGenero.DataSource = Enum.GetValues(typeof(Gener));
        }
    }
}
