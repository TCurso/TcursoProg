﻿using Proyecto.AppCore.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto.Main
{
    public partial class Form2 : Form
    {
        public IPassengerServices passengerService;
        public IEmployeeServices employeeServices;
        public ITicketServices ticketServices;

        public Form2()
        {
            InitializeComponent();
            hideSubMenu();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        #region Submenu
        private void hideSubMenu()
        {
            panelSubMenuBoleto.Visible = false;
            panelSubMenuRegistro.Visible = false;
            panelSubMenuEmpleados.Visible = false;
        }
        private void btnBoleto_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelSubMenuBoleto);
        }
        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }
        private void btnVender_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new FrmBoleto(passengerService, employeeServices, ticketServices));
            hideSubMenu();
        }
        private void btnDetalles_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new FrmDetalle());
            hideSubMenu();
        }
        private void btnVer_Click_1(object sender, EventArgs e)
        {
            openChildFormInPanel(new FrmRegistros());
        }
        private void btnVer_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new FrmEmpleado(employeeServices));
            hideSubMenu();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            openChildFormInPanel(new FrmActualizarEmpleado(employeeServices));
            hideSubMenu();
        }
        private Form activeForm = null;
        private void openChildFormInPanel(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();

            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        #region Paneles Extras
        private void btnRegistro_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubMenuRegistro);
        }
        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubMenuEmpleados);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion

        #endregion

        #region Form
        bool vai = false;
        private void panel8_MouseDown(object sender, MouseEventArgs e)
        {
            vai = true;
        }

        private void panel8_MouseMove(object sender, MouseEventArgs e)
        {
            if (vai == true)
            {
                this.Location = Cursor.Position;

            }
        }

        private void panel8_MouseUp(object sender, MouseEventArgs e)
        {
            vai = false;
        }

        #endregion

    }
}
