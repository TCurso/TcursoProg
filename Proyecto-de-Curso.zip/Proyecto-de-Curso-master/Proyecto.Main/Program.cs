using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Extensions.Hosting;
using Proyecto.Domain.FligthDB;
using Proyecto.Domain.Interfaces;
using Proyecto.Infraestructure.Repositories;
using Proyecto.AppCore.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Proyecto.AppCore.Interfaces;
using Autofac;

namespace Proyecto.Main
{
    static class Program
    {
        public static IConfiguration Configuration;

        [STAThread]
        static void Main()
        {
            Configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").AddEnvironmentVariables().Build();

            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var services = new ServiceCollection();

            services.AddDbContext<AerolineaContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("Default"));
            });
            services.AddScoped<IAerolineDBContext, AerolineaContext>();
            services.AddScoped<IPassengersModel, EFPassengerRepository>();
            services.AddScoped<IPassengerEmployeeModel, EFPassengerEmployeeRepository>();
            services.AddScoped<ITicketModel, EFTicketRepository>();
            services.AddScoped<IEmployeeModel, EFEmployeeRepository>();
            services.AddScoped<IEmployeeServices, EmployeeService>();
            services.AddScoped<IPassengerServices, PassengerService>();
            services.AddScoped<ITicketServices, TicketService>();
            services.AddScoped<IPassengerEmployeeServices, PassengerEmployeeService>();
            services.AddScoped<FrmActualizarEmpleado>();
            services.AddScoped<FrmEmpleado>();
            services.AddScoped<Form1>();
            services.AddScoped<FrmBoleto>();
            services.AddScoped<FrmDetalle>();
            services.AddScoped<Form2>();

            using (var serviceScope = services.BuildServiceProvider())
            {
                var main = serviceScope.GetRequiredService<Form1>();
                Application.Run(main);
            }
        }
    }
}
