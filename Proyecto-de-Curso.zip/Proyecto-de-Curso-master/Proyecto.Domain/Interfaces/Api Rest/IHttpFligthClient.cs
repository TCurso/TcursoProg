﻿using Proyecto.Domain.Entities.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Domain.Interfaces.Api_Rest
{
    public interface IHttpFligthClient
    {
        Task<Fligth> GetFligthByDestination(String destination);
    }
}
