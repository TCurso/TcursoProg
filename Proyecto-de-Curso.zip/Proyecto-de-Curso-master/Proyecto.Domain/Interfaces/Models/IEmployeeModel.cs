﻿using Proyecto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Domain.Interfaces
{
    public interface IEmployeeModel : IModel<Employee>
    {
        List<Employee> FindByName(String name);
        Employee FindById(int id);
    }
}
