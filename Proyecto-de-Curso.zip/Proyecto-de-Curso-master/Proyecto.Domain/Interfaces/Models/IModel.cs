﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Domain.Interfaces
{
    public interface IModel<T>
    {
        int Create(T t);
        bool Delete(T t);
        bool Update(T t);
        List<T> Read();
    }
}
