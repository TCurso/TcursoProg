﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Proyecto.Domain.Entities
{
    public partial class Employee
    {
        public Employee()
        {
            PassengerEmployees = new HashSet<PassengerEmployee>();
            Tickets = new HashSet<Ticket>();
        }

        public int Id { get; set; }
        public int IdPerson { get; set; }
        public string WorkedCard { get; set; }

        public virtual Person IdPersonNavigation { get; set; }
        public virtual ICollection<PassengerEmployee> PassengerEmployees { get; set; }
        public virtual ICollection<Ticket> Tickets { get; set; }
    }
}
