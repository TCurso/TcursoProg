﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Proyecto.Domain.Entities
{
    public partial class Ticket
    {
        public int Id { get; set; }
        public int IdPassenger { get; set; }
        public int IdEmployee { get; set; }
        public int IdFligth { get; set; }
        public string TicketCode { get; set; }
        public double ExtraExpenses { get; set; }
        public double NetPrice { get; set; }
        public DateTime Date { get; set; }

        public virtual Employee IdEmployeeNavigation { get; set; }
        public virtual Fligth IdFligthNavigation { get; set; }
        public virtual Passenger IdPassengerNavigation { get; set; }
    }
}
