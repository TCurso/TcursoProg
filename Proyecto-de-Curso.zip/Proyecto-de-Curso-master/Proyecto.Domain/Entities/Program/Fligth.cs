﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Proyecto.Domain.Entities
{
    public partial class Fligth
    {
        public Fligth()
        {
            Tickets = new HashSet<Ticket>();
        }

        public int Id { get; set; }
        public string AerolineaName { get; set; }
        public string Destination { get; set; }
        public string CountryOfOrigin { get; set; }
        public string Trayectory { get; set; }
        public string FligthClass { get; set; }
        public string TypeOfFligth { get; set; }
        public double PriceFligth { get; set; }

        public virtual ICollection<Ticket> Tickets { get; set; }
    }
}
