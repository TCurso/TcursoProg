﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Domain.Entities.Api
{
    public class Fligth
    {
        public int id { get; set; }
        public String AerolineName { get; set; }
        public String Destination { get; set; }
        public String CountryOfOrigin { get; set; }
        public DateTime date { get; set; }
        public String fligthClass { get; set; }
        public String TypeOfFligth { get; set; }
    }
}
