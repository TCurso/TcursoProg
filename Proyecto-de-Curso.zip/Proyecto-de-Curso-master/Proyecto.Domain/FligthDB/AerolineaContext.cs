﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Proyecto.Domain.Entities;
using Proyecto.Domain.Interfaces;

#nullable disable

namespace Proyecto.Domain.FligthDB
{
    public partial class AerolineaContext : DbContext, IAerolineDBContext
    {
        public AerolineaContext()
        {
        }

        public AerolineaContext(DbContextOptions<AerolineaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Fligth> Fligths { get; set; }
        public virtual DbSet<Passenger> Passengers { get; set; }
        public virtual DbSet<PassengerEmployee> PassengerEmployees { get; set; }
        public virtual DbSet<Person> People { get; set; }
        public virtual DbSet<Ticket> Tickets { get; set; }
        public DbSet<Ticket> tickets { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public DbSet<PassengerEmployee> PassengersEmployees { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-79HMS7E;Initial Catalog=Aerolinea;user=sa;password=123456");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("Employee");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.IdPerson).HasColumnName("idPerson");

                entity.Property(e => e.WorkedCard)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("workedCard");

                entity.HasOne(d => d.IdPersonNavigation)
                    .WithMany(p => p.Employees)
                    .HasForeignKey(d => d.IdPerson)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Person1");
            });

            modelBuilder.Entity<Fligth>(entity =>
            {
                entity.ToTable("Fligth");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AerolineaName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("aerolineaName");

                entity.Property(e => e.CountryOfOrigin)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("countryOfOrigin");

                entity.Property(e => e.Destination)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("destination");

                entity.Property(e => e.FligthClass)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("fligthClass");

                entity.Property(e => e.PriceFligth).HasColumnName("priceFligth");

                entity.Property(e => e.Trayectory)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("trayectory");

                entity.Property(e => e.TypeOfFligth)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("typeOfFligth");
            });

            modelBuilder.Entity<Passenger>(entity =>
            {
                entity.ToTable("Passenger");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.IdPerson).HasColumnName("idPerson");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.WeigthOfSuitcase).HasColumnName("weigthOfSuitcase");

                entity.HasOne(d => d.IdPersonNavigation)
                    .WithMany(p => p.Passengers)
                    .HasForeignKey(d => d.IdPerson)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_person");
            });

            modelBuilder.Entity<PassengerEmployee>(entity =>
            {
                entity.ToTable("PassengerEmployee");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.IdEmployee).HasColumnName("idEmployee");

                entity.Property(e => e.IdEmployeekey).HasColumnName("idEmployeekey");

                entity.Property(e => e.IdPassenger).HasColumnName("idPassenger");

                entity.Property(e => e.IdPassengerkey).HasColumnName("idPassengerkey");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.HasOne(d => d.IdEmployeekeyNavigation)
                    .WithMany(p => p.PassengerEmployees)
                    .HasForeignKey(d => d.IdEmployeekey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Employee1");

                entity.HasOne(d => d.IdPassengerkeyNavigation)
                    .WithMany(p => p.PassengerEmployees)
                    .HasForeignKey(d => d.IdPassengerkey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Passenger1");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.ToTable("Person");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.CardId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("cardId");

                entity.Property(e => e.CivilState)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("civilState");

                entity.Property(e => e.Datetime)
                    .HasColumnType("date")
                    .HasColumnName("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.Gener)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("gener");

                entity.Property(e => e.Lastname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lastname");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");

                entity.Property(e => e.Telephone)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("telephone");
            });

            modelBuilder.Entity<Ticket>(entity =>
            {
                entity.ToTable("Ticket");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Date)
                    .HasColumnType("datetime")
                    .HasColumnName("date");

                entity.Property(e => e.ExtraExpenses).HasColumnName("extraExpenses");

                entity.Property(e => e.IdEmployee).HasColumnName("idEmployee");

                entity.Property(e => e.IdFligth).HasColumnName("idFligth");

                entity.Property(e => e.IdPassenger).HasColumnName("idPassenger");

                entity.Property(e => e.NetPrice).HasColumnName("netPrice");

                entity.Property(e => e.TicketCode)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("ticketCode");

                entity.HasOne(d => d.IdEmployeeNavigation)
                    .WithMany(p => p.Tickets)
                    .HasForeignKey(d => d.IdEmployee)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Employees");

                entity.HasOne(d => d.IdFligthNavigation)
                    .WithMany(p => p.Tickets)
                    .HasForeignKey(d => d.IdFligth)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Fligths");

                entity.HasOne(d => d.IdPassengerNavigation)
                    .WithMany(p => p.Tickets)
                    .HasForeignKey(d => d.IdPassenger)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_Passenger");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
